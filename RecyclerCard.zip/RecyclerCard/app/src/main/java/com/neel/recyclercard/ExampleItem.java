package com.neel.recyclercard;

public class ExampleItem {
    private int mImageResource;
    private String mtext;
    public ExampleItem(int imageResource , String text){
        mImageResource = imageResource;
        mtext = text ;

    }

    public int getmImageResource() {
        return mImageResource;
    }

    public void setmImageResource(int mImageResource) {
        this.mImageResource = mImageResource;
    }

    public String getMtext() {
        return mtext;
    }

    public void setMtext(String mtext) {
        this.mtext = mtext;
    }

}
