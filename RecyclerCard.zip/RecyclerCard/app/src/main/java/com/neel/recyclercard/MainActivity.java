package com.neel.recyclercard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<ExampleItem> examplelist = new ArrayList<>();
        examplelist.add(new ExampleItem(R.drawable.node,"CLicked at studio"));
        examplelist.add(new ExampleItem(R.drawable.oner,"CLicked at studio"));
        examplelist.add(new ExampleItem(R.drawable.twor,"CLicked at studio"));
        examplelist.add(new ExampleItem(R.drawable.threer,"CLicked at studio"));
        examplelist.add(new ExampleItem(R.drawable.fourr,"CLicked at studio"));
        examplelist.add(new ExampleItem(R.drawable.fiver,"CLicked at studio"));

        //config for RV
        public void recyclerViewConfig(){
            //Config  for RV
            recyclerView = findViewById(R.id.recycleView);
            //Performance
            recyclerView.setHasFixedSize(true);
            layoutManager = new LinearLayoutManager(this);
            adapter = new ExampleAdapter(examplelist);


            recyclerView.setLayoutManager(layoutManager);
            recyclerView.setAdapter(adapter);
        }

        public void addCard(int position){
            examplelist.add(position, new ExampleItem(R.drawable.node, "new card added"));
            //adapter.notifyDataSetChanged();
            adapter.notifyItemInserted(position);
        }

        public void deleteCard(int position){
            examplelist.remove(position);
            adapter.notifyItemRemoved(position);
        }




    }
}