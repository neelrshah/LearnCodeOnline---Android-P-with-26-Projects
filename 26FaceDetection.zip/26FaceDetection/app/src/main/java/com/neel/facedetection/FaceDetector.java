package com.neel.facedetection;

import android.app.Application;

import com.google.firebase.FirebaseApp;

public class FaceDetector extends Application {

    public static final String RESULT_TEXT = "RESULT_TEXT";
    public static final String RESULT_DIALOG = "RESULT_DIALOGUE";

    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseApp.initializeApp(this);

    }
}
